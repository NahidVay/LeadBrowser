# Changelog - LeadBrowser Update

## Phase 1: Browser Engine & Browsing Experience Completion

### Browser Engine (GeckoView)
- **Fixed Proxy Logic**: Completely refactored `LocalProxyServer` with Netty to implement a proper SOCKS5 relay tunnel. It now correctly pipes browser traffic through the selected proxy.
- **Improved Runtime Settings**: Enabled JavaScript and console output by default in `GeckoRuntimeSettings`.
- **Proxy Lifecycle**: The local proxy server now starts on-demand when a proxy is configured, reducing unnecessary background resource usage.
- **SSL & Security**: Added `SecurityDelegate` to handle security messages and improved `NavigationDelegate` to capture load errors.

### Browsing Experience
- **Professional Address Bar**:
    - Implemented a modern address bar with `Back`, `Forward`, `Refresh`, `Stop`, and `Home` actions.
    - Added smart URL handling: supports `http`, `https`, `localhost`, `IP addresses`, and automatic Google search for non-URL inputs.
- **Loading Indicators**:
    - Added a linear progress bar at the top of the browser.
    - Added a circular loading indicator during pull-to-refresh.
- **Error & Offline Handling**:
    - Implemented a custom error UI that displays when a page fails to load.
    - Added a "Try Again" action to reload the page after failure.
- **Pull-to-Refresh**: Integrated Accompanist SwipeRefresh to allow users to reload pages by swiping down.

### Tab Management
- **Architecture Refinement**: Refactored `TabManager` and `BrowserViewModel` to properly support multi-tab operations.
- **Lifecycle Fixes**: Improved session closing logic to ensure `GeckoSession` is properly released when tabs are closed or the app is cleared.
- **Tab Operations**: Fixed `create`, `switch`, and `close` operations to ensure UI state remains consistent.

### Performance & Optimization
- **Startup Optimization**: Removed eager proxy server startup from `LeadBrowserApp` to improve initial launch speed.
- **Compose Performance**: Optimized `AndroidView` update logic for `GeckoView` to prevent unnecessary session re-attachments.
- **Memory Management**: Added proper cleanup in `onCleared()` and improved Netty thread group management in `LocalProxyServer`.

### Build & Project Structure
- **Architecture Preserved**: Maintained Hilt, Room, Compose, and the existing package structure.
- **Code Cleanup**: Removed unused imports and placeholder code in `GeckoEngine`.
