package com.leadbrowser.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProxyConfig::class,
        ApiConfig::class,
        CustomDeviceProfile::class,
        VisitHistory::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun proxyDao(): ProxyDao
    abstract fun apiConfigDao(): ApiConfigDao
    abstract fun deviceDao(): DeviceDao
    abstract fun visitHistoryDao(): VisitHistoryDao
}