package com.leadbrowser.data.remote

import com.leadbrowser.data.local.ApiConfig
import com.leadbrowser.data.local.ProxyConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ProxyApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun fetchProxiesFromApi(config: ApiConfig): List<ProxyConfig> = withContext(Dispatchers.IO) {
        try {
            val requestBuilder = Request.Builder()
                .url(config.endpoint)

            config.apiKey?.let { apiKey ->
                requestBuilder.addHeader("Authorization", "Bearer $apiKey")
            }

            val request = requestBuilder.build()
            val response = client.newCall(request).execute()

            if (response.isSuccessful) {
                val body = response.body?.string() ?: return@withContext emptyList()
                parseProxyResponse(body)
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    private fun parseProxyResponse(body: String): List<ProxyConfig> {
        return try {
            val json = JSONObject(body)
            val proxiesArray = json.optJSONArray("proxies")

            if (proxiesArray == null) {
                emptyList()
            } else {
                val proxies = mutableListOf<ProxyConfig>()
                for (i in 0 until proxiesArray.length()) {
                    try {
                        val p = proxiesArray.getJSONObject(i)
                        val proxy = ProxyConfig(
                            host = p.getString("host"),
                            port = p.getInt("port"),
                            username = p.optString("username", null),
                            password = p.optString("password", null),
                            type = p.optString("type", "SOCKS5"),
                            country = p.optString("country", null),
                            city = p.optString("city", null),
                            geoLat = p.optDouble("geoLat", 0.0),
                            geoLon = p.optDouble("geoLon", 0.0),
                            geoTimezone = p.optString("geoTimezone", "America/New_York"),
                            isResidential = p.optBoolean("isResidential", true)
                        )
                        proxies.add(proxy)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                proxies
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }
}