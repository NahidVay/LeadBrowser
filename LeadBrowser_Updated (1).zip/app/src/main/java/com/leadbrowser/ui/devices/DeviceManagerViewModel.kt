package com.leadbrowser.ui.devices

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leadbrowser.data.local.CustomDeviceProfile
import com.leadbrowser.data.local.DeviceDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DeviceManagerViewModel @Inject constructor(
    private val dao: DeviceDao
) : ViewModel() {

    val devices: StateFlow<List<CustomDeviceProfile>> = dao.getCustomDevices()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun add(d: CustomDeviceProfile) = viewModelScope.launch { dao.insert(d) }
    fun delete(d: CustomDeviceProfile) = viewModelScope.launch { dao.delete(d) }
}