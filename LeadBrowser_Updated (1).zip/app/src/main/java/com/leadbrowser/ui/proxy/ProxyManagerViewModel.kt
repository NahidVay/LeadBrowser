package com.leadbrowser.ui.proxy

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leadbrowser.data.local.ApiConfig
import com.leadbrowser.data.local.ApiConfigDao
import com.leadbrowser.data.local.ProxyConfig
import com.leadbrowser.data.local.ProxyDao
import com.leadbrowser.engine.proxy.ProxyRotationManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProxyManagerViewModel @Inject constructor(
    private val pDao: ProxyDao,
    private val aDao: ApiConfigDao,
    private val rot: ProxyRotationManager
) : ViewModel() {

    val proxies: StateFlow<List<ProxyConfig>> = pDao.getAllActiveProxies()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val proxyCount: StateFlow<Int> = flow { emit(pDao.getActiveProxyCount()) }
        .stateIn(viewModelScope, SharingStarted.Lazily, 0)

    fun addProxy(p: ProxyConfig) = viewModelScope.launch { pDao.insert(p) }
    fun deleteProxy(p: ProxyConfig) = viewModelScope.launch { pDao.delete(p) }
    fun saveApi(c: ApiConfig) = viewModelScope.launch {
        aDao.insert(c)
        rot.startAutoRotation(c)
    }
}