package com.leadbrowser.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.swiperefresh.SwipeRefresh
import com.google.accompanist.swiperefresh.rememberSwipeRefreshState
import org.mozilla.geckoview.GeckoView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(modifier: Modifier = Modifier, vm: BrowserViewModel = hiltViewModel()) {
    val state by vm.uiState.collectAsState()
    val refreshing by vm.isRefreshing.collectAsState()
    val activeTab by vm.activeTab.collectAsState()
    var url by remember { mutableStateOf("") }

    val progress by vm.loadingProgress.collectAsState()
    val canGoBack by vm.canGoBack.collectAsState()
    val canGoForward by vm.canGoForward.collectAsState()
    val error by vm.error.collectAsState()
    val focusManager = LocalFocusManager.current

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "📱 ${state.deviceModel}",
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                "IP: ${state.proxyIp ?: "None"} • ${state.browserInfo}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.newSession() }) {
                            Icon(Icons.Default.Refresh, "New Session")
                        }
                    }
                )
                if (progress > 0 && progress < 100) {
                    LinearProgressIndicator(
                        progress = { progress / 100f },
                        modifier = Modifier.fillMaxWidth().height(2.dp),
                    )
                }
            }
        }
    ) { pad ->
        Column(modifier = modifier.then(Modifier.padding(pad)).fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(onClick = { vm.goBack() }, enabled = canGoBack) {
                    Icon(Icons.Default.ArrowBack, "Back")
                }
                IconButton(onClick = { vm.goForward() }, enabled = canGoForward) {
                    Icon(Icons.Default.ArrowForward, "Forward")
                }
                
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Search or type URL") },
                    trailingIcon = {
                        if (progress > 0 && progress < 100) {
                            IconButton(onClick = { vm.stopLoading() }) {
                                Icon(Icons.Default.Close, "Stop")
                            }
                        } else {
                            IconButton(onClick = { vm.refreshPage() }) {
                                Icon(Icons.Default.Refresh, "Refresh")
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        vm.loadUrl(url)
                        focusManager.clearFocus()
                    })
                )
                
                IconButton(onClick = { vm.goHome() }) {
                    Icon(Icons.Default.Home, "Home")
                }
            }
            
            Box(modifier = Modifier.weight(1f)) {
                SwipeRefresh(
                    rememberSwipeRefreshState(refreshing),
                    { vm.refreshPage() }
                ) {
                    AndroidView(
                        factory = { ctx ->
                            GeckoView(ctx)
                        },
                        modifier = Modifier.fillMaxSize(),
                        update = { view ->
                            activeTab?.session?.let { 
                                if (view.session != it) {
                                    view.setSession(it)
                                }
                            }
                        }
                    )
                }
                
                error?.let { errorMsg ->
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Oops! Something went wrong", style = MaterialTheme.typography.headlineSmall)
                        Text(errorMsg, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 8.dp))
                        Button(onClick = { vm.refreshPage() }) {
                            Text("Try Again")
                        }
                    }
                }
                
                if (progress > 0 && progress < 100 && refreshing) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 16.dp)
                    )
                }
            }
        }
    }
}
