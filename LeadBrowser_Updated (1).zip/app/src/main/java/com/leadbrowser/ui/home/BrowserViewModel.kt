package com.leadbrowser.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leadbrowser.engine.BrowserConsistencyEngine
import com.leadbrowser.engine.GeckoEngineManager
import com.leadbrowser.engine.proxy.ProxyManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.mozilla.geckoview.GeckoSession
import javax.inject.Inject

@HiltViewModel
class BrowserViewModel @Inject constructor(
    private val eng: GeckoEngineManager,
    private val tabManager: TabManager,
    private val pm: ProxyManager
) : ViewModel() {

    val tabs = tabManager.tabs
    val activeTab = tabManager.activeTab

    private val _state = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _state

    private val _refresh = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _refresh

    private val _loadingProgress = MutableStateFlow(0)
    val loadingProgress: StateFlow<Int> = _loadingProgress

    private val _canGoBack = MutableStateFlow(false)
    val canGoBack: StateFlow<Boolean> = _canGoBack

    private val _canGoForward = MutableStateFlow(false)
    val canGoForward: StateFlow<Boolean> = _canGoForward

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        eng.initRuntime()
        if (tabManager.tabs.value.isEmpty()) {
            newTab()
        }
    }

    fun newTab() = viewModelScope.launch {
        val pr = pm.getNextProxy()
        val tab = tabManager.createTab(pr)
        setupSessionDelegates(tab.session)
        updateUiState(tab)
    }

    fun switchTab(tabId: String) {
        tabManager.setActiveTab(tabId)
        tabManager.activeTab.value?.let { 
            setupSessionDelegates(it.session)
            updateUiState(it)
        }
    }

    fun closeTab(tabId: String) {
        tabManager.closeTab(tabId)
        if (tabManager.tabs.value.isEmpty()) {
            newTab()
        }
    }

    private fun updateUiState(tab: TabManager.Tab) {
        val p = tab.profile
        val pr = tab.proxy
        _state.value = BrowserUiState(
            proxyIp = pr?.let { "${it.host}:${it.port}" },
            deviceModel = p.deviceModel,
            browserInfo = "${p.browserName} • ${p.osName}",
            country = pr?.country ?: "Unknown",
            resolution = "${p.screenWidth}x${p.screenHeight}"
        )
    }

    fun newSession() = newTab()

    private fun setupSessionDelegates(session: GeckoSession) {
        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onProgressChange(session: GeckoSession, progress: Int) {
                _loadingProgress.value = progress
                if (progress == 100) {
                    _error.value = null
                }
            }
            override fun onSecurityChange(session: GeckoSession, securityInfo: GeckoSession.ProgressDelegate.SecurityInformation) {
            }
        }
        
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBackItem(session: GeckoSession, canGoBack: Boolean) {
                _canGoBack.value = canGoBack
            }
            override fun onCanGoForwardItem(session: GeckoSession, canGoForward: Boolean) {
                _canGoForward.value = canGoForward
            }
            override fun onLoadError(session: GeckoSession, uri: String?, error: GeckoSession.NavigationDelegate.LoadError): GeckoResult<String>? {
                _error.value = "Failed to load $uri: ${error.category} - ${error.code}"
                return GeckoResult.fromValue(null)
            }
        }
    }

    fun loadUrl(u: String) {
        if (u.isBlank()) return
        val trimmed = u.trim()
        val finalUrl = try {
            when {
                trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
                trimmed.startsWith("localhost") || trimmed.startsWith("127.0.0.1") -> "http://$trimmed"
                android.util.Patterns.DOMAIN_NAME.matcher(trimmed).matches() || 
                android.util.Patterns.IP_ADDRESS.matcher(trimmed).matches() -> "https://$trimmed"
                else -> "https://www.google.com/search?q=${java.net.URLEncoder.encode(trimmed, "UTF-8")}"
            }
        } catch (e: Exception) {
            "https://www.google.com/search?q=$trimmed"
        }
        activeTab.value?.session?.loadUri(finalUrl)
    }

    fun goBack() = activeTab.value?.session?.goBack()
    fun goForward() = activeTab.value?.session?.goForward()
    fun stopLoading() = activeTab.value?.session?.stop()
    fun goHome() = loadUrl("https://www.google.com")

    fun refreshPage() = viewModelScope.launch {
        _refresh.value = true
        activeTab.value?.session?.reload(GeckoSession.LOAD_FLAGS_BYPASS_CACHE)
        kotlinx.coroutines.delay(1000)
        _refresh.value = false
    }

    override fun onCleared() {
        super.onCleared()
        tabManager.closeAll()
    }
}

data class BrowserUiState(
    val proxyIp: String? = null,
    val deviceModel: String = "",
    val browserInfo: String = "",
    val country: String = "Unknown",
    val resolution: String = ""
)
