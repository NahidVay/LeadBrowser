package com.leadbrowser.engine

import android.util.LruCache
import org.mozilla.geckoview.GeckoSession
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionCache @Inject constructor() {

    private val maxSessions = 50

    private val cache = object : LruCache<String, CachedSession>(maxSessions) {
        override fun sizeOf(key: String, value: CachedSession): Int {
            return 10240
        }

        override fun entryRemoved(
            evicted: Boolean,
            key: String,
            oldValue: CachedSession,
            newValue: CachedSession?
        ) {
            if (evicted) {
                oldValue.session.close()
            }
        }
    }

    data class CachedSession(
        val session: GeckoSession,
        val profile: ConsistentProfile,
        val lastAccessed: Long = System.currentTimeMillis()
    )

    fun getOrCreateSession(
        sessionId: String,
        profile: ConsistentProfile,
        creator: () -> GeckoSession
    ): GeckoSession {
        val cached = cache.get(sessionId)
        if (cached != null) {
            cache.put(sessionId, cached.copy(lastAccessed = System.currentTimeMillis()))
            return cached.session
        }
        val session = creator()
        cache.put(sessionId, CachedSession(session, profile))
        return session
    }

    fun getSession(sessionId: String): GeckoSession? {
        val cached = cache.get(sessionId)
        if (cached != null) {
            cache.put(sessionId, cached.copy(lastAccessed = System.currentTimeMillis()))
            return cached.session
        }
        return null
    }

    fun removeSession(sessionId: String) {
        cache.remove(sessionId)
    }

    fun clearAll() {
        cache.evictAll()
    }

    fun getActiveSessionCount(): Int {
        return cache.size()
    }
}