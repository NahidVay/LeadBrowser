package com.leadbrowser.engine

import android.content.Context
import com.leadbrowser.data.local.ProxyConfig
import com.leadbrowser.engine.network.DnsOverHttps
import com.leadbrowser.engine.proxy.LocalProxyServer
import com.leadbrowser.engine.proxy.ProxyManager
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GeckoEngineManager @Inject constructor(
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: Context,
    private val proxyManager: ProxyManager,
    private val sessionCache: SessionCache,
    private val localProxyServer: LocalProxyServer
) {

    private lateinit var runtime: GeckoRuntime
    private val dns = DnsOverHttps()

    fun initRuntime() {
        if (::runtime.isInitialized) return

        val settings = GeckoRuntimeSettings.Builder()
            .javaScriptEnabled(true)
            .consoleOutputEnabled(true)
            .build()

        runtime = GeckoRuntime.create(context, settings)
        
        // Use extensions for preferences if standard API is restricted
        dns.configureDns(runtime)
        registerExt()
    }

    private fun registerExt() {
        runtime.webExtensionController.ensureBuiltIn(
            "resource://android/assets/extensions/antidetect/",
            "antidetect@leadbrowser.com"
        ).accept({
            android.util.Log.d("Gecko", "Ext registered")
        }, {
            android.util.Log.e("Gecko", "Ext fail", it)
        })
    }

    fun createNewSession(profile: ConsistentProfile, proxy: ProxyConfig?): GeckoSession {
        if (proxy != null) {
            localProxyServer.setCurrentProxy(proxy)
            localProxyServer.start()
        }

        val sid = UUID.randomUUID().toString()
        return sessionCache.getOrCreateSession(sid, profile) {
            val ss = GeckoSessionSettings.Builder()
                .contextId(sid)
                .usePrivateMode(true)
                .userAgentOverride(profile.userAgent)
                .suspendOnPause(true)
                .build()

            val sess = GeckoSession(ss)
            injectConfig(sess, profile, proxy)
            
            if (proxy != null) {
                runtime.settings.setProxyConfig(
                    org.mozilla.geckoview.GeckoRuntimeSettings.Builder()
                        .proxySocks5("127.0.0.1:1080")
                        .build().proxyConfig
                )
            }

            sess.open(runtime)
            sess
        }
    }

    private fun injectConfig(sess: GeckoSession, p: ConsistentProfile, proxy: ProxyConfig?) {
        sess.contentDelegate = object : GeckoSession.ContentDelegate {}

        sess.securityDelegate = object : GeckoSession.SecurityDelegate {
            override fun onSecurityMessage(
                session: GeckoSession,
                message: GeckoSession.SecurityDelegate.SecurityMessage
            ) {
                // Handle security messages if needed
            }
        }

        sess.permissionDelegate = object : GeckoSession.PermissionDelegate {
            override fun onContentPermissionRequest(
                s: GeckoSession,
                perm: GeckoSession.PermissionDelegate.ContentPermission
            ): GeckoResult<Int>? {
                return GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
            }
        }
    }

    private fun calcTzOffset(tz: String) = try {
        val z = java.time.ZoneId.of(tz)
        z.rules.getOffset(java.time.Instant.now()).totalSeconds / 60
    } catch (e: Exception) {
        0
    }
}
