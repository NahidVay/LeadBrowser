package com.leadbrowser.engine

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.webkit.MimeTypeMap
import dagger.hilt.android.qualifiers.ApplicationContext
import org.mozilla.geckoview.GeckoSession
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadManager @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as android.app.DownloadManager

    fun handleDownload(
        session: GeckoSession,
        response: GeckoSession.WebResponseInfo
    ): Long? {
        val uri = response.uri
        val filename = extractFilename(uri, response.filename)
        val mimeType = response.contentType ?: guessMimeType(filename)

        val request = android.app.DownloadManager.Request(Uri.parse(uri))
            .setTitle(filename)
            .setDescription("Downloading...")
            .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                "LeadBrowser/$filename"
            )
            .setMimeType(mimeType)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)

        return try {
            downloadManager.enqueue(request)
        } catch (e: Exception) {
            null
        }
    }

    private fun extractFilename(uri: String, suggested: String?): String {
        if (!suggested.isNullOrEmpty()) return suggested

        return try {
            val path = Uri.parse(uri).lastPathSegment ?: "download_${System.currentTimeMillis()}"
            if (path.contains('.')) path else "$path.bin"
        } catch (e: Exception) {
            "download_${System.currentTimeMillis()}"
        }
    }

    private fun guessMimeType(filename: String): String {
        val ext = filename.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: "application/octet-stream"
    }
}