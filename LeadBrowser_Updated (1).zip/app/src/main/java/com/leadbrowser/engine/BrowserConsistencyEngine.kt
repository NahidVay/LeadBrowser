package com.leadbrowser.engine

import com.leadbrowser.data.local.CustomDeviceProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

@Singleton
class BrowserConsistencyEngine @Inject constructor(
    private val customDevicesFlow: Flow<List<CustomDeviceProfile>>
) {

    suspend fun generateConsistentProfile(): ConsistentProfile {
        val customDevices = customDevicesFlow.first()
        return if (Random.nextFloat() < 0.15f && customDevices.isNotEmpty()) {
            generateFromCustom(customDevices.random())
        } else {
            generateFromDefaultPool()
        }
    }

    private fun generateFromDefaultPool(): ConsistentProfile {
        val androidVersion = selectAndroidVersion()
        val device = DEFAULT_DEVICES.random()
        val browserType = selectBrowserType()
        val chromeVer = Random.nextInt(120, 132)
        val firefoxVer = Random.nextInt(120, 127)
        val samsungVer = "${Random.nextInt(22, 26)}.${Random.nextInt(0, 5)}"

        val ua = when (browserType) {
            BrowserType.CHROME -> "Mozilla/5.0 (Linux; Android $androidVersion; ${device.model}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chromeVer.0.0.0 Mobile Safari/537.36"
            BrowserType.SAMSUNG -> "Mozilla/5.0 (Linux; Android $androidVersion; ${device.model}) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/$samsungVer Chrome/$chromeVer.0.0.0 Mobile Safari/537.36"
            BrowserType.FIREFOX -> "Mozilla/5.0 (Android $androidVersion; Mobile; rv:$firefoxVer.0) Gecko/$firefoxVer.0 Firefox/$firefoxVer.0"
            BrowserType.EDGE -> "Mozilla/5.0 (Linux; Android $androidVersion; ${device.model}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chromeVer.0.0.0 Mobile Safari/537.36 EdgA/$chromeVer.0.0.0"
        }

        return ConsistentProfile(
            userAgent = ua,
            platform = "Linux armv8l",
            locale = "en-US",
            timezone = "America/New_York",
            hasChromeObject = browserType != BrowserType.FIREFOX,
            hasNotificationAPI = true,
            hasServiceWorker = true,
            plugins = emptyList(),
            mimeTypes = listOf(
                MimeType("application/pdf", "pdf"),
                MimeType("image/png", "png"),
                MimeType("image/jpeg", "jpeg"),
                MimeType("image/webp", "webp")
            ),
            hardwareConcurrency = device.cpuCores,
            deviceMemory = device.ram,
            maxTouchPoints = 5,
            screenWidth = device.screenWidth,
            screenHeight = device.screenHeight,
            screenColorDepth = 24,
            webglVendor = device.gpuVendor,
            webglRenderer = device.gpuRenderer,
            fonts = listOf(
                "Roboto",
                "Noto Sans",
                "Droid Sans",
                "Droid Serif",
                "Noto Color Emoji",
                "Noto Sans Symbols"
            ),
            connectionType = "4g",
            connectionDownlink = Random.nextDouble(2.0, 20.0),
            connectionRTT = Random.nextInt(100, 300),
            canvasNoiseSeed = Random.nextLong(),
            audioNoiseSeed = Random.nextLong(),
            vendor = if (browserType == BrowserType.FIREFOX) "" else "Google Inc.",
            vendorSub = "",
            productSub = if (browserType == BrowserType.FIREFOX) "20100101" else "20030107",
            isMobile = true,
            touchSupport = true,
            devicePixelRatio = device.dpr,
            deviceModel = device.model,
            browserName = browserType.name,
            osName = "Android $androidVersion"
        )
    }

    private fun generateFromCustom(custom: CustomDeviceProfile): ConsistentProfile {
        val androidVer = listOf("13", "14", "15", "16").random()
        val browserType = selectBrowserType()
        val chromeVer = Random.nextInt(120, 132)
        val ua = "Mozilla/5.0 (Linux; Android $androidVer; ${custom.model}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chromeVer.0.0.0 Mobile Safari/537.36"

        return ConsistentProfile(
            userAgent = ua,
            platform = "Linux armv8l",
            locale = "en-US",
            timezone = "America/New_York",
            hasChromeObject = true,
            hasNotificationAPI = true,
            hasServiceWorker = true,
            plugins = emptyList(),
            mimeTypes = listOf(
                MimeType("application/pdf", "pdf"),
                MimeType("image/png", "png")
            ),
            hardwareConcurrency = custom.cpuCores,
            deviceMemory = custom.ram,
            maxTouchPoints = 5,
            screenWidth = custom.screenWidth,
            screenHeight = custom.screenHeight,
            screenColorDepth = 24,
            webglVendor = custom.gpuVendor,
            webglRenderer = custom.gpuRenderer,
            fonts = listOf("Roboto", "Noto Sans", "Droid Sans"),
            connectionType = "4g",
            connectionDownlink = Random.nextDouble(2.0, 15.0),
            connectionRTT = Random.nextInt(100, 250),
            canvasNoiseSeed = Random.nextLong(),
            audioNoiseSeed = Random.nextLong(),
            vendor = "Google Inc.",
            vendorSub = "",
            productSub = "20030107",
            isMobile = true,
            touchSupport = true,
            devicePixelRatio = custom.dpr,
            deviceModel = custom.model,
            browserName = "Custom-${browserType.name}",
            osName = "Android $androidVer"
        )
    }

    private fun selectAndroidVersion(): String = when (Random.nextFloat()) {
        in 0f..0.05f -> "11"
        in 0.05f..0.15f -> "12"
        in 0.15f..0.35f -> "13"
        in 0.35f..0.60f -> "14"
        in 0.60f..0.80f -> "15"
        else -> "16"
    }

    private fun selectBrowserType(): BrowserType = when (Random.nextFloat()) {
        in 0f..0.55f -> BrowserType.CHROME
        in 0.55f..0.70f -> BrowserType.SAMSUNG
        in 0.70f..0.85f -> BrowserType.FIREFOX
        else -> BrowserType.EDGE
    }
}

enum class BrowserType {
    CHROME, SAMSUNG, FIREFOX, EDGE
}

data class ConsistentProfile(
    val userAgent: String,
    val platform: String,
    val locale: String,
    val timezone: String,
    val hasChromeObject: Boolean,
    val hasNotificationAPI: Boolean,
    val hasServiceWorker: Boolean,
    val plugins: List<BrowserPlugin>,
    val mimeTypes: List<MimeType>,
    val hardwareConcurrency: Int,
    val deviceMemory: Int,
    val maxTouchPoints: Int,
    val screenWidth: Int,
    val screenHeight: Int,
    val screenColorDepth: Int,
    val webglVendor: String,
    val webglRenderer: String,
    val fonts: List<String>,
    val connectionType: String,
    val connectionDownlink: Double,
    val connectionRTT: Int,
    val canvasNoiseSeed: Long,
    val audioNoiseSeed: Long,
    val vendor: String,
    val vendorSub: String,
    val productSub: String,
    val isMobile: Boolean = true,
    val touchSupport: Boolean = true,
    val devicePixelRatio: Float = 2.625f,
    val deviceModel: String = "",
    val browserName: String = "",
    val osName: String = ""
)

data class BrowserPlugin(
    val name: String,
    val description: String,
    val filename: String
)

data class MimeType(
    val type: String,
    val suffixes: String
)

data class DefaultDevice(
    val model: String,
    val cpuCores: Int,
    val ram: Int,
    val screenWidth: Int,
    val screenHeight: Int,
    val dpr: Float,
    val gpuVendor: String,
    val gpuRenderer: String
)

val DEFAULT_DEVICES = listOf(
    // Google Pixel Series
    DefaultDevice("Pixel 6", 8, 8, 412, 915, 2.625f, "ARM", "Mali-G78"),
    DefaultDevice("Pixel 6 Pro", 8, 12, 412, 892, 3.5f, "ARM", "Mali-G78"),
    DefaultDevice("Pixel 6a", 8, 6, 412, 915, 2.625f, "ARM", "Mali-G77"),
    DefaultDevice("Pixel 7", 8, 8, 412, 915, 2.625f, "ARM", "Mali-G710"),
    DefaultDevice("Pixel 7 Pro", 8, 12, 412, 892, 3.5f, "ARM", "Mali-G710"),
    DefaultDevice("Pixel 7a", 8, 8, 412, 915, 2.625f, "ARM", "Mali-G77"),
    DefaultDevice("Pixel 8", 8, 8, 412, 915, 2.625f, "ARM", "Mali-G715"),
    DefaultDevice("Pixel 8 Pro", 8, 12, 412, 892, 3.5f, "ARM", "Mali-G715"),
    DefaultDevice("Pixel 8a", 8, 8, 412, 915, 2.625f, "ARM", "Mali-G77"),
    DefaultDevice("Pixel 9", 8, 8, 412, 915, 2.625f, "ARM", "Mali-G720"),
    DefaultDevice("Pixel 9 Pro", 8, 12, 412, 892, 3.5f, "ARM", "Mali-G720"),

    // Samsung Galaxy S Series
    DefaultDevice("SM-G991B", 8, 8, 384, 854, 3.0f, "ARM", "Mali-G78"),
    DefaultDevice("SM-G996B", 8, 8, 384, 854, 3.0f, "ARM", "Mali-G78"),
    DefaultDevice("SM-G998B", 8, 12, 412, 915, 3.5f, "ARM", "Mali-G78"),
    DefaultDevice("SM-S901B", 8, 8, 384, 854, 3.0f, "ARM", "Mali-G710"),
    DefaultDevice("SM-S906B", 8, 8, 384, 854, 3.0f, "ARM", "Mali-G710"),
    DefaultDevice("SM-S908B", 8, 12, 412, 915, 3.5f, "ARM", "Mali-G710"),
    DefaultDevice("SM-S911B", 8, 8, 384, 854, 3.0f, "ARM", "Mali-G715"),
    DefaultDevice("SM-S916B", 8, 8, 384, 854, 3.0f, "ARM", "Mali-G715"),
    DefaultDevice("SM-S918B", 8, 12, 412, 915, 3.5f, "ARM", "Mali-G715"),
    DefaultDevice("SM-S921B", 8, 8, 384, 854, 3.0f, "ARM", "Mali-G720"),
    DefaultDevice("SM-S926B", 8, 8, 384, 854, 3.0f, "ARM", "Mali-G720"),
    DefaultDevice("SM-S928B", 8, 12, 412, 915, 3.5f, "ARM", "Mali-G720"),

    // Samsung Galaxy A Series
    DefaultDevice("SM-A536B", 8, 6, 412, 914, 2.625f, "ARM", "Mali-G68"),
    DefaultDevice("SM-A546B", 8, 8, 412, 914, 2.625f, "ARM", "Mali-G68"),
    DefaultDevice("SM-A556B", 8, 8, 412, 914, 2.625f, "ARM", "Mali-G68"),
    DefaultDevice("SM-A346B", 8, 6, 412, 914, 2.625f, "ARM", "Mali-G68"),
    DefaultDevice("SM-A256B", 8, 4, 412, 914, 2.625f, "ARM", "Mali-G57"),

    // Samsung Fold/Flip
    DefaultDevice("SM-F946B", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 740"),
    DefaultDevice("SM-F731B", 8, 8, 412, 915, 2.625f, "ARM", "Adreno 740"),

    // OnePlus
    DefaultDevice("OnePlus 9", 8, 8, 412, 915, 3.5f, "ARM", "Adreno 660"),
    DefaultDevice("OnePlus 9 Pro", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 660"),
    DefaultDevice("OnePlus 10", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 730"),
    DefaultDevice("OnePlus 10 Pro", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 730"),
    DefaultDevice("OnePlus 11", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 740"),
    DefaultDevice("OnePlus 12", 8, 16, 412, 915, 3.5f, "ARM", "Adreno 750"),
    DefaultDevice("OnePlus 13", 8, 16, 412, 915, 3.5f, "ARM", "Adreno 830"),
    DefaultDevice("OnePlus Nord", 8, 8, 412, 915, 2.625f, "ARM", "Adreno 620"),

    // Xiaomi / Redmi / POCO
    DefaultDevice("Redmi Note 11", 8, 4, 393, 873, 2.75f, "ARM", "Mali-G68"),
    DefaultDevice("Redmi Note 12", 8, 6, 412, 914, 2.625f, "ARM", "Mali-G68"),
    DefaultDevice("Redmi Note 13", 8, 8, 412, 914, 2.625f, "ARM", "Mali-G68"),
    DefaultDevice("Redmi Note 14 Pro", 8, 8, 412, 914, 2.625f, "ARM", "Adreno 619"),
    DefaultDevice("Xiaomi 12", 8, 8, 412, 915, 3.5f, "ARM", "Adreno 730"),
    DefaultDevice("Xiaomi 13", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 740"),
    DefaultDevice("Xiaomi 14", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 750"),
    DefaultDevice("Xiaomi 15", 8, 16, 412, 915, 3.5f, "ARM", "Adreno 830"),
    DefaultDevice("POCO X5", 8, 6, 393, 873, 2.75f, "ARM", "Adreno 619"),
    DefaultDevice("POCO F5", 8, 8, 393, 873, 2.75f, "ARM", "Adreno 730"),

    // Realme
    DefaultDevice("RMX3700", 8, 8, 412, 914, 2.625f, "ARM", "Mali-G78"),
    DefaultDevice("RMX3701", 8, 8, 412, 914, 2.625f, "ARM", "Mali-G68"),
    DefaultDevice("Realme GT 2", 8, 8, 412, 914, 2.625f, "ARM", "Adreno 660"),
    DefaultDevice("Realme GT 5 Pro", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 750"),

    // Motorola
    DefaultDevice("motorola edge 30", 8, 6, 412, 914, 2.625f, "ARM", "Adreno 642L"),
    DefaultDevice("motorola edge 40", 8, 8, 412, 914, 2.625f, "ARM", "Dimensity 8020"),
    DefaultDevice("motorola edge 50", 8, 8, 412, 914, 2.625f, "ARM", "Snapdragon 7 Gen 3"),
    DefaultDevice("moto g54", 8, 4, 393, 873, 2.75f, "ARM", "Dimensity 7020"),
    DefaultDevice("moto g84", 8, 6, 412, 914, 2.625f, "ARM", "Snapdragon 695"),

    // Sony
    DefaultDevice("Sony Xperia 1 IV", 8, 8, 384, 854, 3.0f, "ARM", "Adreno 660"),
    DefaultDevice("Sony Xperia 1 V", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 740"),
    DefaultDevice("Sony Xperia 5 IV", 8, 8, 384, 854, 3.0f, "ARM", "Adreno 660"),
    DefaultDevice("Sony Xperia 10 IV", 8, 6, 393, 873, 2.75f, "ARM", "Adreno 610"),

    // ASUS
    DefaultDevice("ASUS ROG Phone 7", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 740"),
    DefaultDevice("ASUS Zenfone 10", 8, 8, 412, 915, 2.625f, "ARM", "Adreno 660"),
    DefaultDevice("ASUS ROG Phone 8", 8, 16, 412, 915, 3.5f, "ARM", "Adreno 830"),

    // Nothing
    DefaultDevice("Nothing Phone 1", 8, 8, 412, 915, 2.625f, "ARM", "Adreno 710"),
    DefaultDevice("Nothing Phone 2", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 730"),

    // vivo
    DefaultDevice("vivo X90 Pro", 8, 12, 412, 915, 3.5f, "ARM", "Dimensity 9200"),
    DefaultDevice("vivo X100", 8, 12, 412, 915, 3.5f, "ARM", "Dimensity 9300"),
    DefaultDevice("vivo X200", 8, 16, 412, 915, 3.5f, "ARM", "Dimensity 9400"),

    // OPPO
    DefaultDevice("OPPO Find X5", 8, 8, 412, 914, 2.625f, "ARM", "Adreno 660"),
    DefaultDevice("OPPO Find X7", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 740"),
    DefaultDevice("OPPO Find X8", 8, 12, 412, 915, 3.5f, "ARM", "Dimensity 9400"),

    // Honor
    DefaultDevice("Honor Magic 5 Pro", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 740"),
    DefaultDevice("Honor Magic 6 Pro", 8, 16, 412, 915, 3.5f, "ARM", "Adreno 750"),

    // Huawei
    DefaultDevice("Huawei Mate 60 Pro", 8, 12, 412, 915, 3.5f, "ARM", "Kirin 9000S"),

    // ZTE
    DefaultDevice("ZTE Axon 40", 8, 8, 412, 914, 2.625f, "ARM", "Adreno 660"),

    // Nokia
    DefaultDevice("Nokia XR21", 8, 6, 412, 914, 2.625f, "ARM", "Adreno 610"),

    // TCL
    DefaultDevice("TCL 40 XE 5G", 8, 4, 393, 873, 2.75f, "ARM", "Dimensity 6100+"),

    // Infinix
    DefaultDevice("Infinix GT 20 Pro", 8, 12, 412, 915, 3.5f, "ARM", "Adreno 740"),

    // Tecno
    DefaultDevice("Tecno Camon 20", 8, 8, 412, 914, 2.625f, "ARM", "Helio G85")
)