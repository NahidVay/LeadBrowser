package com.leadbrowser.engine

import com.leadbrowser.data.local.ProxyConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TabManager @Inject constructor(
    private val browserConsistencyEngine: BrowserConsistencyEngine,
    private val sessionCache: SessionCache
) {

    data class Tab(
        val id: String,
        val title: String = "New Tab",
        val url: String = "",
        val session: GeckoSession,
        val profile: ConsistentProfile,
        val proxy: ProxyConfig?,
        val isActive: Boolean = false
    )

    private val _tabs = MutableStateFlow<List<Tab>>(emptyList())
    val tabs: StateFlow<List<Tab>> = _tabs

    private val _activeTab = MutableStateFlow<Tab?>(null)
    val activeTab: StateFlow<Tab?> = _activeTab

    @Inject lateinit var geckoEngineManager: GeckoEngineManager

    suspend fun createTab(proxy: ProxyConfig? = null): Tab {
        val profile = browserConsistencyEngine.generateConsistentProfile()
        val session = geckoEngineManager.createNewSession(profile, proxy)
        val tabId = java.util.UUID.randomUUID().toString()

        val tab = Tab(
            id = tabId,
            session = session,
            profile = profile,
            proxy = proxy
        )

        _tabs.value = _tabs.value + tab
        setActiveTab(tab.id)
        return tab
    }

    fun setActiveTab(tabId: String) {
        _tabs.value = _tabs.value.map {
            it.copy(isActive = it.id == tabId)
        }
        _activeTab.value = _tabs.value.find { it.id == tabId }
    }

    fun closeTab(tabId: String) {
        val tab = _tabs.value.find { it.id == tabId } ?: return
        
        // Ensure session is detached from runtime before closing
        tab.session.close()

        _tabs.value = _tabs.value.filter { it.id != tabId }

        if (tab.isActive && _tabs.value.isNotEmpty()) {
            setActiveTab(_tabs.value.first().id)
        } else if (_tabs.value.isEmpty()) {
            _activeTab.value = null
        }
    }

    fun updateTab(tabId: String, title: String? = null, url: String? = null) {
        _tabs.value = _tabs.value.map { tab ->
            if (tab.id == tabId) {
                tab.copy(
                    title = title ?: tab.title,
                    url = url ?: tab.url
                )
            } else tab
        }
    }

    fun closeAll() {
        _tabs.value.forEach { it.session.close() }
        _tabs.value = emptyList()
        _activeTab.value = null
    }

    fun getTabStates(): List<CrashRecovery.TabState> {
        return _tabs.value.map { tab ->
            CrashRecovery.TabState(
                sessionId = tab.id,
                url = tab.url,
                title = tab.title,
                profileId = tab.profile.deviceModel,
                proxyId = tab.proxy?.id
            )
        }
    }
}