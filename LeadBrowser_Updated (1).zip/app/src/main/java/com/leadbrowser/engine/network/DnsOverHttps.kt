package com.leadbrowser.engine.network

import org.mozilla.geckoview.GeckoRuntime

class DnsOverHttps {

    fun configureDns(runtime: GeckoRuntime) {
        // DNS configuration will be handled via WebExtension or standard runtime settings if available
    }
}
