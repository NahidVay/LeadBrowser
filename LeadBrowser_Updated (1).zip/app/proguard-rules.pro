# Add project specific ProGuard rules here.

# Keep Hilt generated classes
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }

# Keep Room entities
-keep class com.leadbrowser.data.local.** { *; }

# Keep GeckoView
-keep class org.mozilla.geckoview.** { *; }

# Keep Netty
-keep class io.netty.** { *; }