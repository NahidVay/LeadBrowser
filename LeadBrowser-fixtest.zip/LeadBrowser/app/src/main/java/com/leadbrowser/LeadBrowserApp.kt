package com.leadbrowser

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class LeadBrowserApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // Startup services temporarily disabled for debugging.
        // We will re-enable them one by one after the app launches successfully.
    }

    override fun onTerminate() {
        super.onTerminate()
    }
}