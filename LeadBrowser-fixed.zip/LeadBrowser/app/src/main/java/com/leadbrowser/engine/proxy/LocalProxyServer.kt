package com.leadbrowser.engine.proxy

import com.leadbrowser.data.local.ProxyConfig
import io.netty.bootstrap.Bootstrap
import io.netty.bootstrap.ServerBootstrap
import io.netty.channel.Channel
import io.netty.channel.ChannelHandlerContext
import io.netty.channel.ChannelInitializer
import io.netty.channel.ChannelInboundHandlerAdapter
import io.netty.channel.ChannelOption
import io.netty.channel.SimpleChannelInboundHandler
import io.netty.channel.nio.NioEventLoopGroup
import io.netty.channel.socket.SocketChannel
import io.netty.channel.socket.nio.NioServerSocketChannel
import io.netty.channel.socket.nio.NioSocketChannel
import io.netty.handler.codec.socksx.v5.DefaultSocks5CommandResponse
import io.netty.handler.codec.socksx.v5.DefaultSocks5CommandRequest
import io.netty.handler.codec.socksx.v5.Socks5CommandStatus
import io.netty.handler.codec.socksx.v5.Socks5CommandType
import io.netty.handler.codec.socksx.v5.Socks5InitialRequest
// Removed unused import
import io.netty.handler.codec.socksx.v5.Socks5ServerEncoder
import io.netty.handler.proxy.Socks5ProxyHandler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.net.InetSocketAddress
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocalProxyServer @Inject constructor() {

    private val bossGroup = NioEventLoopGroup(1)
    private val workerGroup = NioEventLoopGroup()
    private var channel: Channel? = null

    private val _status = MutableStateFlow(Status.STOPPED)
    val serverStatus: StateFlow<Status> = _status

    private var currentProxy: ProxyConfig? = null

    enum class Status {
        STARTED, STOPPED, ERROR
    }

    fun start() {
        if (_status.value == Status.STARTED) return
        try {
            val bootstrap = ServerBootstrap()
                .group(bossGroup, workerGroup)
                .channel(NioServerSocketChannel::class.java)
                .childHandler(object : ChannelInitializer<SocketChannel>() {
                    override fun initChannel(ch: SocketChannel) {
                        ch.pipeline().addLast(SocksServerInitializer())
                    }
                })
                .option(ChannelOption.SO_BACKLOG, 128)
                .childOption(ChannelOption.SO_KEEPALIVE, true)

            channel = bootstrap.bind(1080).sync().channel()
            _status.value = Status.STARTED
        } catch (e: Exception) {
            _status.value = Status.ERROR
            e.printStackTrace()
        }
    }

    fun setCurrentProxy(proxy: ProxyConfig) {
        currentProxy = proxy
    }

    fun stop() {
        channel?.close()
        bossGroup.shutdownGracefully()
        workerGroup.shutdownGracefully()
        _status.value = Status.STOPPED
    }

    private inner class SocksServerInitializer : ChannelInitializer<SocketChannel>() {
        override fun initChannel(ch: SocketChannel) {
            ch.pipeline().addLast(io.netty.handler.codec.socksx.SocksPortUnificationServerHandler())
            ch.pipeline().addLast(SocksServerHandler())
        }
    }

    private inner class SocksServerHandler : SimpleChannelInboundHandler<Any>() {
        override fun channelRead0(ctx: ChannelHandlerContext, msg: Any) {
            if (msg is Socks5InitialRequest) {
                ctx.writeAndFlush(io.netty.handler.codec.socksx.v5.DefaultSocks5InitialResponse(io.netty.handler.codec.socksx.v5.Socks5AuthMethod.NO_AUTH))
            } else if (msg is DefaultSocks5CommandRequest && msg.type() == Socks5CommandType.CONNECT) {
                handleConnect(ctx, msg)
            }
        }

        private fun handleConnect(ctx: ChannelHandlerContext, req: DefaultSocks5CommandRequest) {
            val proxy = currentProxy ?: run {
                ctx.writeAndFlush(
                    DefaultSocks5CommandResponse(Socks5CommandStatus.FAILURE, req.dstAddrType())
                )
                return
            }

            val bootstrap = Bootstrap()
                .group(ctx.channel().eventLoop())
                .channel(NioSocketChannel::class.java)
                .handler(object : ChannelInitializer<SocketChannel>() {
                    override fun initChannel(ch: SocketChannel) {
                        if (proxy.username != null && proxy.password != null) {
                            ch.pipeline().addLast(
                                Socks5ProxyHandler(
                                    InetSocketAddress(proxy.host, proxy.port),
                                    proxy.username,
                                    proxy.password
                                )
                            )
                        } else {
                            ch.pipeline().addLast(
                                Socks5ProxyHandler(InetSocketAddress(proxy.host, proxy.port))
                            )
                        }
                    }
                })

            bootstrap.connect(proxy.host, proxy.port).addListener { future ->
                if (future.isSuccess) {
                    ctx.writeAndFlush(
                        DefaultSocks5CommandResponse(Socks5CommandStatus.SUCCESS, req.dstAddrType())
                    )
                } else {
                    ctx.writeAndFlush(
                        DefaultSocks5CommandResponse(Socks5CommandStatus.FAILURE, req.dstAddrType())
                    )
                }
            }
        }

        override fun exceptionCaught(ctx: ChannelHandlerContext, cause: Throwable) {
            cause.printStackTrace()
            ctx.close()
        }
    }

    private class RelayHandler(private val other: Channel) : ChannelInboundHandlerAdapter() {
        override fun channelRead(ctx: ChannelHandlerContext, msg: Any) {
            other.writeAndFlush(msg)
        }

        override fun channelInactive(ctx: ChannelHandlerContext) {
            other.close()
        }
    }
}
