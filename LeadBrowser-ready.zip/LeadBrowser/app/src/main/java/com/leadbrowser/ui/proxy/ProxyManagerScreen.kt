package com.leadbrowser.ui.proxy

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Api
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.leadbrowser.data.local.ApiConfig
import com.leadbrowser.data.local.ProxyConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProxyManagerScreen(modifier: Modifier = Modifier, vm: ProxyManagerViewModel = hiltViewModel()) {
    val proxies by vm.proxies.collectAsState()
    val count by vm.proxyCount.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var showApi by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Proxies ($count)") }) },
        floatingActionButton = {
            Column(Alignment.End) {
                SmallFloatingActionButton(
                    onClick = { showApi = true },
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Icon(Icons.Default.Api, "API")
                }
                Spacer(Modifier.height(16.dp))
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, "Add")
                }
            }
        }
    ) { pad ->
        if (proxies.isEmpty()) {
            Box(
                modifier.then(Modifier.padding(pad)).fillMaxSize(),
                Alignment.Center
            ) {
                Text("No proxies. Tap + to add.")
            }
        } else {
            LazyColumn(
                modifier.then(Modifier.padding(pad)).fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(proxies) { p ->
                    ProxyCard(p) { vm.deleteProxy(p) }
                }
            }
        }
    }
    if (showAdd) AddProxyDialog({ showAdd = false }) { vm.addProxy(it); showAdd = false }
    if (showApi) ApiDialog({ showApi = false }) { vm.saveApi(it); showApi = false }
}

@Composable
fun ProxyCard(p: ProxyConfig, del: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp).fillMaxWidth(),
            Arrangement.SpaceBetween,
            Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("${p.host}:${p.port}", MaterialTheme.typography.titleMedium)
                Text("Type: ${p.type}", MaterialTheme.typography.bodySmall)
                p.country?.let { Text("Country: $it", MaterialTheme.typography.bodySmall) }
                if (p.isResidential) Text(
                    "✓ Residential",
                    MaterialTheme.typography.bodySmall,
                    MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = del) { Icon(Icons.Default.Delete, "Del") }
        }
    }
}

@Composable
fun AddProxyDialog(dis: () -> Unit, add: (ProxyConfig) -> Unit) {
    var h by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var u by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var c by remember { mutableStateOf("") }
    var tz by remember { mutableStateOf("America/New_York") }
    var res by remember { mutableStateOf(true) }

    AlertDialog(
        dis,
        { Text("Add Proxy") },
        {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(h, { h = it }, label = { Text("Host") })
                OutlinedTextField(p, { p = it }, label = { Text("Port") })
                OutlinedTextField(u, { u = it }, label = { Text("User") })
                OutlinedTextField(pw, { pw = it }, label = { Text("Pass") })
                OutlinedTextField(c, { c = it }, label = { Text("Country") })
                OutlinedTextField(tz, { tz = it }, label = { Text("Timezone") })
                Row(Alignment.CenterVertically) {
                    Checkbox(res, { res = it })
                    Text("Residential")
                }
            }
        },
        {
            TextButton({
                add(
                    ProxyConfig(
                        host = h,
                        port = p.toIntOrNull() ?: 1080,
                        username = u.ifBlank { null },
                        password = pw.ifBlank { null },
                        country = c.ifBlank { null },
                        geoTimezone = tz,
                        isResidential = res
                    )
                )
            }) { Text("Add") }
        },
        { TextButton(dis) { Text("Cancel") } }
    )
}

@Composable
fun ApiDialog(dis: () -> Unit, save: (ApiConfig) -> Unit) {
    var n by remember { mutableStateOf("") }
    var e by remember { mutableStateOf("") }
    var k by remember { mutableStateOf("") }
    var r by remember { mutableStateOf("300") }

    AlertDialog(
        dis,
        { Text("API Rotation") },
        {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text("Name") })
                OutlinedTextField(e, { e = it }, label = { Text("Endpoint") })
                OutlinedTextField(k, { k = it }, label = { Text("Key") })
                OutlinedTextField(r, { r = it }, label = { Text("Refresh (sec)") })
            }
        },
        {
            TextButton({
                save(
                    ApiConfig(
                        name = n,
                        endpoint = e,
                        apiKey = k.ifBlank { null },
                        refreshInterval = (r.toLongOrNull() ?: 300) * 1000
                    )
                )
            }) { Text("Save") }
        },
        { TextButton(dis) { Text("Cancel") } }
    )
}