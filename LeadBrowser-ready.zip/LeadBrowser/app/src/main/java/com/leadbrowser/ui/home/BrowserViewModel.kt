package com.leadbrowser.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.leadbrowser.engine.BrowserConsistencyEngine
import com.leadbrowser.engine.GeckoEngineManager
import com.leadbrowser.engine.proxy.ProxyManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.mozilla.geckoview.GeckoSession
import javax.inject.Inject

@HiltViewModel
class BrowserViewModel @Inject constructor(
    private val eng: GeckoEngineManager,
    private val cons: BrowserConsistencyEngine,
    private val pm: ProxyManager
) : ViewModel() {

    private var sess: GeckoSession? = null

    private val _state = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _state

    private val _refresh = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _refresh

    init {
        eng.initRuntime()
        newSession()
    }

    fun getOrCreateSession(): GeckoSession {
        return sess ?: run {
            newSession()
            sess!!
        }
    }

    fun newSession() = viewModelScope.launch {
        sess?.close()
        val p = cons.generateConsistentProfile()
        val pr = pm.getNextProxy()
        sess = eng.createNewSession(p, pr)
        _state.value = BrowserUiState(
            proxyIp = pr?.let { "${it.host}:${it.port}" },
            deviceModel = p.deviceModel,
            browserInfo = "${p.browserName} • ${p.osName}",
            country = pr?.country ?: "Unknown",
            resolution = "${p.screenWidth}x${p.screenHeight}"
        )
    }

    fun loadUrl(u: String) {
        val f = if (!u.startsWith("http")) "https://$u" else u
        sess?.loadUri(f)
    }

    fun refreshPage() = viewModelScope.launch {
        _refresh.value = true
        sess?.reload(GeckoSession.LOAD_FLAGS_BYPASS_CACHE)
        kotlinx.coroutines.delay(1000)
        _refresh.value = false
    }

    override fun onCleared() {
        super.onCleared()
        sess?.close()
    }
}

data class BrowserUiState(
    val proxyIp: String? = null,
    val deviceModel: String = "",
    val browserInfo: String = "",
    val country: String = "Unknown",
    val resolution: String = ""
)