package com.leadbrowser.di

import android.content.Context
import androidx.room.Room
import com.leadbrowser.data.local.AppDatabase
import com.leadbrowser.data.local.ApiConfigDao
import com.leadbrowser.data.local.DeviceDao
import com.leadbrowser.data.local.ProxyDao
import com.leadbrowser.data.local.VisitHistoryDao
import com.leadbrowser.data.remote.ProxyApiService
import com.leadbrowser.engine.BrowserConsistencyEngine
import com.leadbrowser.engine.CrashRecovery
import com.leadbrowser.engine.DownloadManager
import com.leadbrowser.engine.SessionCache
import com.leadbrowser.engine.SessionPersistence
import com.leadbrowser.engine.TabManager
import com.leadbrowser.engine.proxy.LocalProxyServer
import com.leadbrowser.engine.proxy.ProxyHealthChecker
import com.leadbrowser.engine.proxy.ProxyManager
import com.leadbrowser.engine.proxy.ProxyRotationManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "lead_browser_database"
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideProxyDao(database: AppDatabase): ProxyDao {
        return database.proxyDao()
    }

    @Provides
    fun provideApiConfigDao(database: AppDatabase): ApiConfigDao {
        return database.apiConfigDao()
    }

    @Provides
    fun provideDeviceDao(database: AppDatabase): DeviceDao {
        return database.deviceDao()
    }

    @Provides
    fun provideVisitHistoryDao(database: AppDatabase): VisitHistoryDao {
        return database.visitHistoryDao()
    }

    @Provides
    @Singleton
    fun provideProxyApiService(): ProxyApiService {
        return ProxyApiService()
    }

    @Provides
    @Singleton
    fun provideLocalProxyServer(): LocalProxyServer {
        return LocalProxyServer()
    }

    @Provides
    @Singleton
    fun provideSessionCache(): SessionCache {
        return SessionCache()
    }

    @Provides
    @Singleton
    fun provideBrowserConsistencyEngine(database: AppDatabase): BrowserConsistencyEngine {
        return BrowserConsistencyEngine(database.deviceDao().getCustomDevices())
    }

    @Provides
    @Singleton
    fun provideProxyManager(
        proxyDao: ProxyDao,
        localProxyServer: LocalProxyServer
    ): ProxyManager {
        return ProxyManager(proxyDao, localProxyServer)
    }

    @Provides
    @Singleton
    fun provideProxyRotationManager(
        apiConfigDao: ApiConfigDao,
        proxyDao: ProxyDao,
        proxyApiService: ProxyApiService
    ): ProxyRotationManager {
        return ProxyRotationManager(apiConfigDao, proxyDao, proxyApiService)
    }

    @Provides
    @Singleton
    fun provideProxyHealthChecker(proxyDao: ProxyDao): ProxyHealthChecker {
        return ProxyHealthChecker(proxyDao)
    }

    @Provides
    @Singleton
    fun provideSessionPersistence(@ApplicationContext context: Context): SessionPersistence {
        return SessionPersistence(context)
    }

    @Provides
    @Singleton
    fun provideDownloadManager(@ApplicationContext context: Context): DownloadManager {
        return DownloadManager(context)
    }

    @Provides
    @Singleton
    fun provideCrashRecovery(@ApplicationContext context: Context): CrashRecovery {
        return CrashRecovery(context)
    }

    @Provides
    @Singleton
    fun provideTabManager(
        browserConsistencyEngine: BrowserConsistencyEngine,
        sessionCache: SessionCache
    ): TabManager {
        return TabManager(browserConsistencyEngine, sessionCache)
    }
}