package com.leadbrowser.ui.devices

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.leadbrowser.data.local.CustomDeviceProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceManagerScreen(modifier: Modifier = Modifier, vm: DeviceManagerViewModel = hiltViewModel()) {
    val devices by vm.devices.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Custom Devices (${devices.size})") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, "Add")
            }
        }
    ) { pad ->
        LazyColumn(
            modifier.then(Modifier.padding(pad)).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(devices) { d ->
                DeviceCard(d) { vm.delete(d) }
            }
        }
    }
    if (showAdd) AddDeviceDialog({ showAdd = false }) { vm.add(it); showAdd = false }
}

@Composable
fun DeviceCard(d: CustomDeviceProfile, del: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp).fillMaxWidth(),
            Arrangement.SpaceBetween,
            Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(d.model, MaterialTheme.typography.titleMedium)
                Text(
                    "${d.screenWidth}x${d.screenHeight} • DPR ${d.dpr}",
                    MaterialTheme.typography.bodySmall
                )
                Text(
                    "CPU: ${d.cpuCores}c • RAM: ${d.ram}GB",
                    MaterialTheme.typography.bodySmall
                )
                Text("GPU: ${d.gpuRenderer}", MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = del) { Icon(Icons.Default.Delete, "Del") }
        }
    }
}

@Composable
fun AddDeviceDialog(dis: () -> Unit, add: (CustomDeviceProfile) -> Unit) {
    var n by remember { mutableStateOf("") }
    var m by remember { mutableStateOf("") }
    var w by remember { mutableStateOf("393") }
    var h by remember { mutableStateOf("873") }
    var dpr by remember { mutableStateOf("2.75") }
    var c by remember { mutableStateOf("8") }
    var r by remember { mutableStateOf("6") }
    var gv by remember { mutableStateOf("ARM") }
    var gr by remember { mutableStateOf("Adreno 619") }

    AlertDialog(
        dis,
        { Text("Add Device") },
        {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text("Name") })
                OutlinedTextField(m, { m = it }, label = { Text("Model") })
                OutlinedTextField(w, { w = it }, label = { Text("Width") })
                OutlinedTextField(h, { h = it }, label = { Text("Height") })
                OutlinedTextField(dpr, { dpr = it }, label = { Text("DPR") })
                OutlinedTextField(c, { c = it }, label = { Text("CPU Cores") })
                OutlinedTextField(r, { r = it }, label = { Text("RAM GB") })
                OutlinedTextField(gv, { gv = it }, label = { Text("GPU Vendor") })
                OutlinedTextField(gr, { gr = it }, label = { Text("GPU Renderer") })
            }
        },
        {
            TextButton({
                add(
                    CustomDeviceProfile(
                        name = n,
                        model = m,
                        screenWidth = w.toIntOrNull() ?: 393,
                        screenHeight = h.toIntOrNull() ?: 873,
                        dpr = dpr.toFloatOrNull() ?: 2.75f,
                        cpuCores = c.toIntOrNull() ?: 8,
                        ram = r.toIntOrNull() ?: 6,
                        gpuVendor = gv,
                        gpuRenderer = gr
                    )
                )
            }) { Text("Save") }
        },
        { TextButton(dis) { Text("Cancel") } }
    )
}