package com.leadbrowser.engine

import android.content.Context
import com.leadbrowser.data.local.ProxyConfig
import com.leadbrowser.engine.network.DnsOverHttps
import com.leadbrowser.engine.proxy.LocalProxyServer
import com.leadbrowser.engine.proxy.ProxyManager
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebExtension
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GeckoEngineManager @Inject constructor(
    private val context: Context,
    private val proxyManager: ProxyManager,
    private val sessionCache: SessionCache,
    private val localProxyServer: LocalProxyServer
) {

    private lateinit var runtime: GeckoRuntime
    private val dns = DnsOverHttps()

    fun initRuntime() {
        if (::runtime.isInitialized) return

        val settings = GeckoRuntimeSettings.Builder()
            .consoleOutputEnabled(true)
            .webContentIsolationStrategy(GeckoRuntimeSettings.WEB_CONTENT_ISOLATION_STRATEGY_ISOLATED_PROCESS)
            .proxyConfig(
                GeckoRuntimeSettings.ProxyConfig.Builder()
                    .proxyType(GeckoRuntimeSettings.ProxyConfig.PROXY_TYPE_SOCKS)
                    .proxyHost("127.0.0.1")
                    .proxyPort(1080)
                    .build()
            )
            .preferences {
                it.setBoolean("media.peerconnection.enabled", false)
                it.setBoolean("media.navigator.video.enabled", false)
                it.setBoolean("media.navigator.audio.enabled", false)
                it.setString("network.proxy.type", "socks")
                it.setString("network.proxy.socks", "127.0.0.1")
                it.setInt("network.proxy.socks_port", 1080)
                it.setBoolean("network.proxy.socks_remote_dns", true)
            }
            .build()

        runtime = GeckoRuntime.create(context, settings)
        dns.configureDns(runtime)
        registerExt()
    }

    private fun registerExt() {
        runtime.registerWebExtension(
            WebExtension(
                "resource://android/assets/extensions/antidetect/",
                runtime,
                WebExtension.Flags.ALLOW_CONTENT_MESSAGING
            )
        ).accept({
            android.util.Log.d("Gecko", "Ext registered")
        }, {
            android.util.Log.e("Gecko", "Ext fail", it)
        })
    }

    fun createNewSession(profile: ConsistentProfile, proxy: ProxyConfig?): GeckoSession {
        proxy?.let { localProxyServer.setCurrentProxy(it) }

        val sid = UUID.randomUUID().toString()
        return sessionCache.getOrCreateSession(sid, profile) {
            val ss = GeckoSessionSettings.Builder()
                .contextId(sid)
                .usePrivateMode(true)
                .userAgentOverride(profile.userAgent)
                .build()

            val sess = GeckoSession(ss)
            injectConfig(sess, profile, proxy)
            sess.open(runtime)
            sess
        }
    }

    private fun injectConfig(sess: GeckoSession, p: ConsistentProfile, proxy: ProxyConfig?) {
        sess.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onLocationChange(s: GeckoSession, url: String?) {
                val tz = proxy?.geoTimezone ?: p.timezone
                val lat = proxy?.geoLat ?: 0.0
                val lon = proxy?.geoLon ?: 0.0
                val mime = p.mimeTypes.joinToString(",") { """{"type":"${it.type}","suffixes":"${it.suffixes}"}""" }
                val fonts = p.fonts.joinToString(",") { """"$it"""" }
                val cfg = """{"canvasNoiseSeed":${p.canvasNoiseSeed},"audioNoiseSeed":${p.audioNoiseSeed},"webglVendor":"${p.webglVendor}","webglRenderer":"${p.webglRenderer}","timezone":"$tz","timezoneOffset":${calcTzOffset(tz)},"geoLat":$lat,"geoLon":$lon,"locale":"${p.locale}","userAgent":"${p.userAgent}","platform":"${p.platform}","screenWidth":${p.screenWidth},"screenHeight":${p.screenHeight},"screenColorDepth":${p.screenColorDepth},"hardwareConcurrency":${p.hardwareConcurrency},"deviceMemory":${p.deviceMemory},"maxTouchPoints":${p.maxTouchPoints},"hasChromeObject":${p.hasChromeObject},"mimeTypes":[$mime],"fonts":[$fonts],"connectionType":"${p.connectionType}","connectionDownlink":${p.connectionDownlink},"connectionRTT":${p.connectionRTT},"vendor":"${p.vendor}","vendorSub":"${p.vendorSub}","productSub":"${p.productSub}","isMobile":${p.isMobile},"touchSupport":${p.touchSupport},"devicePixelRatio":${p.devicePixelRatio}}"""
                s.evaluateJavascript("window.__ANTIDETECT_CONFIG__=$cfg;", null)
            }

            override fun onTitleChange(s: GeckoSession, t: String?) {}
            override fun onCrash(s: GeckoSession) {}
            override fun onKill(s: GeckoSession) {}
            override fun onFullScreen(s: GeckoSession, f: Boolean) {}
            override fun onExternalResponse(s: GeckoSession, r: GeckoSession.WebResponseInfo) {}
            override fun onFirstComposite(s: GeckoSession) {}
            override fun onFirstContentfulPaint(s: GeckoSession) {}
            override fun onFocusRequest(s: GeckoSession) {}
            override fun onContextMenu(s: GeckoSession, x: Int, y: Int, u: String?, e: Int, src: String?) {}
            override fun onFocusedElementChanged(s: GeckoSession, el: GeckoSession.FocusedElement?) {}
            override fun onPaintStatusReset(s: GeckoSession) {}
            override fun onPointerIconRequest(s: GeckoSession, i: GeckoResult<android.view.PointerIcon>) {}
            override fun onWebAppManifest(s: GeckoSession, m: org.json.JSONObject) {}
            override fun onPreviewImage(s: GeckoSession, pi: String) {}
        }

        sess.permissionDelegate = object : GeckoSession.PermissionDelegate {
            override fun onContentPermissionRequest(
                s: GeckoSession, u: String?, t: Int,
                cb: GeckoSession.PermissionDelegate.Callback
            ) {
                if (t == PERMISSION_GEOLOCATION) cb.reject() else cb.grant()
            }

            override fun onMediaPermissionRequest(
                s: GeckoSession, u: String,
                v: Array<out GeckoSession.PermissionDelegate.MediaSource>?,
                a: Array<out GeckoSession.PermissionDelegate.MediaSource>?,
                cb: GeckoSession.PermissionDelegate.MediaCallback
            ) {
                cb.reject()
            }

            private val PERMISSION_GEOLOCATION = 4
        }
    }

    private fun calcTzOffset(tz: String) = try {
        val z = java.time.ZoneId.of(tz)
        z.rules.getOffset(java.time.Instant.now()).totalSeconds / 60
    } catch (e: Exception) {
        0
    }
}