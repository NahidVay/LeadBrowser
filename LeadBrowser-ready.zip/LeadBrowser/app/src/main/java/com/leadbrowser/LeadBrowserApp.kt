package com.leadbrowser

import android.app.Application
import com.leadbrowser.engine.CrashRecovery
import com.leadbrowser.engine.proxy.LocalProxyServer
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class LeadBrowserApp : Application() {

    @Inject
    lateinit var localProxyServer: LocalProxyServer

    @Inject
    lateinit var crashRecovery: CrashRecovery

    override fun onCreate() {
        super.onCreate()
        
        // Start local proxy server on port 1080
        localProxyServer.start()
        
        // Mark app as running for crash detection
        crashRecovery.markRunning()
    }

    override fun onTerminate() {
        super.onTerminate()
        
        // Stop local proxy server
        localProxyServer.stop()
        
        // Mark app as stopped cleanly
        crashRecovery.markStopped()
    }
}