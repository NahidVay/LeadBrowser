package com.leadbrowser.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.swiperefresh.SwipeRefresh
import com.google.accompanist.swiperefresh.rememberSwipeRefreshState
import org.mozilla.geckoview.GeckoView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(modifier: Modifier = Modifier, vm: BrowserViewModel = hiltViewModel()) {
    val state by vm.uiState.collectAsState()
    val refreshing by vm.isRefreshing.collectAsState()
    val session by vm.session.collectAsState()
    var url by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "📱 ${state.deviceModel}",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            "IP: ${state.proxyIp ?: "None"} • ${state.browserInfo}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { vm.newSession() }) {
                        Icon(Icons.Default.Refresh, "New Session")
                    }
                }
            )
        }
    ) { pad ->
        Column(modifier = modifier.then(Modifier.padding(pad)).fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    url,
                    { url = it },
                    Modifier.weight(1f),
                    singleLine = true,
                    placeholder = { Text("Enter URL") }
                )
                Button(onClick = { vm.loadUrl(url) }) { Text("Go") }
            }
            SwipeRefresh(
                rememberSwipeRefreshState(refreshing),
                { vm.refreshPage() }
            ) {
                AndroidView(
                    factory = { ctx ->
                        GeckoView(ctx)
                    },
                    modifier = Modifier.fillMaxSize(),
                    update = { view ->
                        session?.let { 
                            if (view.session != it) {
                                view.setSession(it)
                            }
                        }
                    }
                )
            }
        }
    }
}
